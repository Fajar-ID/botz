## FOR TERMUX/UBUNTU/SSH USER
```bash
apt update && apt upgrade
apt install git -y
apt install nodejs -y
apt install ffmpeg -y
git clone https://github.com/FadlyID/naze-md
cd naze
npm install
```
## RECOMMENDED INSTALL ON TERMUX
```bash
pkg install yarn
yarn
```
## Installing
```bash
$ node .
```